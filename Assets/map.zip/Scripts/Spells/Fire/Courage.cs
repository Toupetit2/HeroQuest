using UnityEngine;

[CreateAssetMenu(fileName = "Courage", menuName = "Scriptable Objects/SpellsEffects/Courage")]
public class Courage : CardEffect
{
    public override void Execute(GameManager gameManager) 
    {
        Hero user = gameManager.GetSelectedHero();

        user.bonusAttackDice += 2;
    }
}
